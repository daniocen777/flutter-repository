import 'package:flutter/material.dart';
import 'package:country_house/screens/allcountries.dart';

void main() => runApp(new MaterialApp(
      home: new AllCountries(),
      debugShowCheckedModeBanner: false,
    ));
